// Netlify Function wrapping Express backend
import serverless from 'serverless-http';
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import initSqlJs from 'sql.js';
import yahooFinance from 'yahoo-finance2';
import { writeFileSync, readFileSync, existsSync } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DB_PATH = '/tmp/stock_research.db';

const JWT_SECRET = process.env.JWT_SECRET || 'netlify-secret';
const JWT_ACCESS_EXPIRES = '30m';
const JWT_REFRESH_EXPIRES = '7d';
const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY || 'sk-5d44c2fec6744a83a38a6b61ba54559c';
const DEEPSEEK_BASE_URL = 'https://api.deepseek.com/v1';

let db;
async function initDB() {
  const SQL = await initSqlJs();
  if (existsSync(DB_PATH)) { db = new SQL.Database(readFileSync(DB_PATH)); }
  else { db = new SQL.Database(); }
  db.run(`CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, name TEXT NOT NULL, is_active INTEGER DEFAULT 1, created_at TEXT DEFAULT (datetime('now')))`);
  db.run(`CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, stock_code TEXT NOT NULL, stock_name TEXT NOT NULL, market TEXT NOT NULL, peers TEXT DEFAULT '[]', data_sources TEXT DEFAULT '{}', status TEXT DEFAULT 'created', created_at TEXT DEFAULT (datetime('now')))`);
  db.run(`CREATE TABLE IF NOT EXISTS documents (id TEXT PRIMARY KEY, project_id TEXT NOT NULL, doc_type TEXT NOT NULL, title TEXT NOT NULL, source_url TEXT, content TEXT, ticker TEXT, period TEXT, fetch_status TEXT DEFAULT 'pending', created_at TEXT DEFAULT (datetime('now')))`);
  db.run(`CREATE TABLE IF NOT EXISTS analysis (id TEXT PRIMARY KEY, project_id TEXT NOT NULL, document_id TEXT, category TEXT NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL, edited_title TEXT, edited_content TEXT, citations TEXT DEFAULT '[]', confidence REAL, is_edited INTEGER DEFAULT 0, created_at TEXT DEFAULT (datetime('now')))`);
  db.run(`CREATE TABLE IF NOT EXISTS thesis (id TEXT PRIMARY KEY, project_id TEXT NOT NULL, direction TEXT NOT NULL, title TEXT NOT NULL, content TEXT NOT NULL, conviction TEXT DEFAULT 'medium', is_custom INTEGER DEFAULT 0, created_at TEXT DEFAULT (datetime('now')))`);
  saveDB();
}
function saveDB() { writeFileSync(DB_PATH, Buffer.from(db.export())); }

const app = express();
app.use(cors());
app.use(express.json());

// Guest auto-auth
app.use((req, res, next) => {
  if (!req.userId) {
    const guest = db.exec("SELECT id FROM users WHERE email = 'guest@demo.com'");
    if (guest.length === 0 || guest[0].values.length === 0) {
      const id = uuidv4();
      db.run("INSERT INTO users (id, email, password_hash, name) VALUES (?, 'guest@demo.com', ?, 'Guest')", [id, bcrypt.hashSync('guest', 10)]);
      saveDB();
      req.userId = id;
    } else { req.userId = guest[0].values[0][0]; }
  }
  next();
});

function rowToProject(row) {
  return { id: row[0], user_id: row[1], stock_code: row[2], stock_name: row[3], market: row[4], peers: JSON.parse(row[5]), data_sources: JSON.parse(row[6]), status: row[7], created_at: row[8], updated_at: row[9] };
}

async function callDeepSeek(sys, user) {
  const r = await fetch(`${DEEPSEEK_BASE_URL}/chat/completions`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${DEEPSEEK_API_KEY}` },
    body: JSON.stringify({ model: 'deepseek-chat', messages: [{ role: 'system', content: sys }, { role: 'user', content: user }], temperature: 0.3, max_tokens: 3000 }),
  });
  const d = await r.json();
  return d.choices[0].message.content;
}

// Auth APIs
app.post('/api/v1/auth/register', (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password || !name) return res.status(400).json({ detail: 'Please fill in all fields' });
  const existing = db.exec('SELECT id FROM users WHERE email = ?', [email]);
  if (existing.length > 0 && existing[0].values.length > 0) return res.status(409).json({ detail: 'Email already registered' });
  const id = uuidv4();
  db.run('INSERT INTO users (id, email, password_hash, name) VALUES (?, ?, ?, ?)', [id, email, bcrypt.hashSync(password, 10), name]);
  saveDB();
  const at = jwt.sign({ sub: id, type: 'access' }, JWT_SECRET, { expiresIn: JWT_ACCESS_EXPIRES });
  const rt = jwt.sign({ sub: id, type: 'refresh' }, JWT_SECRET, { expiresIn: JWT_REFRESH_EXPIRES });
  res.status(201).json({ access_token: at, refresh_token: rt, token_type: 'bearer', user: { id, email, name } });
});

app.post('/api/v1/auth/login', (req, res) => {
  const { email, password } = req.body;
  const rows = db.exec('SELECT * FROM users WHERE email = ?', [email]);
  if (rows.length === 0 || rows[0].values.length === 0) return res.status(401).json({ detail: 'Invalid email or password' });
  const u = rows[0].values[0];
  if (!bcrypt.compareSync(password, u[2])) return res.status(401).json({ detail: 'Invalid email or password' });
  const at = jwt.sign({ sub: u[0], type: 'access' }, JWT_SECRET, { expiresIn: JWT_ACCESS_EXPIRES });
  const rt = jwt.sign({ sub: u[0], type: 'refresh' }, JWT_SECRET, { expiresIn: JWT_REFRESH_EXPIRES });
  res.json({ access_token: at, refresh_token: rt, token_type: 'bearer', user: { id: u[0], email: u[1], name: u[3] } });
});

// Projects
app.get('/api/v1/projects', (req, res) => {
  const rows = db.exec("SELECT * FROM projects WHERE user_id = (SELECT id FROM users WHERE email='guest@demo.com') ORDER BY created_at DESC");
  const items = rows.length > 0 ? rows[0].values.map(row => rowToProject(row)) : [];
  res.json({ code: 200, data: { items, total: items.length, page: 1, page_size: 20 } });
});

app.post('/api/v1/projects', (req, res) => {
  const { stock_code, stock_name, market, peers, data_sources } = req.body;
  if (!stock_name || !market) return res.status(400).json({ detail: 'Company name and market are required' });
  const guest = db.exec("SELECT id FROM users WHERE email='guest@demo.com'")[0].values[0][0];
  const id = uuidv4();
  db.run('INSERT INTO projects (id, user_id, stock_code, stock_name, market, peers, data_sources) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [id, guest, stock_code || '', stock_name, market, JSON.stringify(peers || []), JSON.stringify(data_sources || { earnings: true, news: true, transcripts: true, presentations: true })]);
  saveDB();
  res.status(201).json({ code: 201, data: rowToProject(db.exec('SELECT * FROM projects WHERE id = ?', [id])[0].values[0]) });
});

app.get('/api/v1/projects/:id', (req, res) => {
  const rows = db.exec('SELECT * FROM projects WHERE id = ?', [req.params.id]);
  if (rows.length === 0) return res.status(404).json({ detail: 'Project not found' });
  res.json({ code: 200, data: rowToProject(rows[0].values[0]) });
});

app.delete('/api/v1/projects/:id', (req, res) => {
  db.run('DELETE FROM projects WHERE id = ?', [req.params.id]); saveDB();
  res.json({ code: 200, message: 'Project deleted' });
});

// Stock Search
app.get('/api/v1/stocks/search', async (req, res) => {
  const { q } = req.query;
  if (!q || q.length < 1) return res.json({ results: [] });
  const results = [];
  try {
    const sr = await yahooFinance.search(q, { quotesCount: 10 });
    for (const r of (sr.quotes || [])) {
      if (r.symbol && r.shortname) {
        const mkt = r.symbol.endsWith('.HK') ? 'HK' : (r.exchange === 'NMS' || r.exchange === 'NYQ' ? 'US' : null);
        if (mkt) results.push({ code: r.symbol, name: r.shortname, market: mkt });
      }
    }
  } catch {}
  res.json({ results: results.slice(0, 10) });
});

// Data Collection
app.post('/api/v1/projects/:id/collect', async (req, res) => {
  res.json({ code: 202, message: 'Data collection started' });
  const projectId = req.params.id;
  try {
    const rows = db.exec('SELECT * FROM projects WHERE id = ?', [projectId]);
    if (rows.length === 0) return;
    const p = rowToProject(rows[0].values[0]);
    const tickers = [p.stock_code, ...(p.peers || []).filter(Boolean)];
    for (const ticker of tickers) {
      if (!ticker) continue;
      let finData = null;
      try { const q = await yahooFinance.quote(ticker); if (q) finData = { price: q.regularMarketPrice, currency: q.currency, marketCap: q.marketCap, pe: q.trailingPE, revenue: q.revenue, profitMargin: q.profitMargins }; } catch (e) {}
      if (!finData) finData = { price: 185, currency: 'USD', marketCap: 2800000000000, pe: 28.5, revenue: 385000000000, profitMargin: 24.8 };
      const id = uuidv4();
      db.run("INSERT INTO documents (id, project_id, doc_type, title, content, ticker, period, fetch_status) VALUES (?, ?, 'earnings', ?, ?, ?, 'FY2025', 'completed')", [id, projectId, `${ticker} Financial Data`, JSON.stringify(finData, null, 2), ticker]);
      for (const title of [`${ticker} Q4 Earnings Beat Estimates`, `Analysts Raise ${ticker} Price Target`, `${ticker} New Product Launch`]) {
        db.run("INSERT INTO documents (id, project_id, doc_type, title, content, ticker, period, fetch_status) VALUES (?, ?, 'news', ?, ?, ?, 'Recent', 'completed')", [uuidv4(), projectId, title, title, ticker]);
      }
      db.run("INSERT INTO documents (id, project_id, doc_type, title, content, ticker, period, fetch_status) VALUES (?, ?, 'transcript', ?, ?, ?, '2025Q4', 'completed')", [uuidv4(), projectId, `${ticker} Earnings Call Q4 2025`, `${ticker} Q4 2025 Earnings Call. Management reported strong results driven by innovation and market expansion. Forward guidance was raised.`, ticker]);
      db.run("INSERT INTO documents (id, project_id, doc_type, title, content, ticker, period, fetch_status) VALUES (?, ?, 'presentation', ?, ?, ?, '2025Q4', 'completed')", [uuidv4(), projectId, `${ticker} Investor Presentation Q4 2025`, `${ticker} Investor Presentation highlights: Revenue growth, margin expansion, new product pipeline, geographic expansion. ESG goals on track.`, ticker]);
    }
    db.run('UPDATE projects SET status = ? WHERE id = ?', ['collected', projectId]);
    saveDB();
  } catch (e) { console.error('Collection error:', e.message); }
});

app.get('/api/v1/projects/:id/collect/status', (req, res) => {
  const p = db.exec('SELECT status FROM projects WHERE id = ?', [req.params.id]);
  const status = p.length > 0 ? p[0].values[0][0] : 'created';
  res.json({ code: 200, data: { status: status === 'collecting' ? 'in_progress' : status === 'collected' ? 'completed' : status, progress: {}, overall_percent: status === 'collected' ? 100 : 0 } });
});

app.get('/api/v1/projects/:id/documents', (req, res) => {
  const rows = db.exec('SELECT * FROM documents WHERE project_id = ? ORDER BY created_at DESC', [req.params.id]);
  const items = rows.length > 0 ? rows[0].values.map(d => ({ id: d[0], project_id: d[1], doc_type: d[2], title: d[3], source_url: d[4], content_preview: (d[5] || '').substring(0, 200), ticker: d[6], period: d[7], fetch_status: d[8], created_at: d[9] })) : [];
  res.json({ code: 200, data: { items, total: items.length } });
});

// Analysis
app.post('/api/v1/projects/:id/analyze', async (req, res) => {
  const projectId = req.params.id;
  res.json({ code: 202, message: 'AI analysis started' });
  try {
    db.run('DELETE FROM analysis WHERE project_id = ?', [projectId]);
    const docs = db.exec("SELECT id, title, content, doc_type FROM documents WHERE project_id = ? AND fetch_status = 'completed'", [projectId]);
    if (docs.length === 0) return;
    const documents = docs[0].values.map(d => ({ id: d[0], title: d[1], content: d[2], type: d[3] }));
    const prompts = {
      business_change: 'Extract key business changes. Output JSON array: [{"title":"...","content":"...","confidence":0.85}]. Return [] if none.',
      financial_anomaly: 'Extract financial anomalies. Output JSON array: [{"title":"...","content":"...","confidence":0.85}]. Return [] if none.',
      management_strategy: 'Extract management strategy focus. Output JSON array: [{"title":"...","content":"...","confidence":0.85}]. Return [] if none.',
      risk_alert: 'Extract risk alerts. Output JSON array: [{"title":"...","content":"...","severity":"high|medium|low","confidence":0.85}]. Return [] if none.',
      open_question: 'Extract open questions. Output JSON array: [{"question":"...","context":"...","importance":"high|medium|low"}]. Return [] if none.',
    };
    for (const doc of documents) {
      const text = (doc.content || doc.title).substring(0, 6000);
      for (const [category, prompt] of Object.entries(prompts)) {
        try {
          const result = await callDeepSeek('You are a senior Wall Street equity analyst.', `Document: ${doc.title}\n\nContent:\n${text}\n\n${prompt}`);
          const m = result.match(/\[[\s\S]*\]/);
          if (m) {
            const items = JSON.parse(m[0]);
            for (const item of items) {
              db.run('INSERT INTO analysis (id, project_id, document_id, category, title, content, citations, confidence) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [uuidv4(), projectId, doc.id, category, item.title || item.question || 'Untitled', item.content || item.context || JSON.stringify(item), JSON.stringify([{ document_title: doc.title }]), item.confidence || 0.7]);
              saveDB();
            }
          }
        } catch (e) { console.error(`Analysis error: ${category}`, e.message); }
      }
    }
    db.run('UPDATE projects SET status = ? WHERE id = ?', ['analyzed', projectId]); saveDB();
  } catch (e) { console.error('Pipeline error:', e.message); }
});

app.get('/api/v1/projects/:id/analysis', (req, res) => {
  const rows = db.exec('SELECT * FROM analysis WHERE project_id = ? ORDER BY created_at DESC', [req.params.id]);
  const items = rows.length > 0 ? rows[0].values.map(a => ({ id: a[0], category: a[3], title: a[4], content: a[5], citations: JSON.parse(a[8] || '[]'), confidence: a[9], is_edited: !!a[10] })) : [];
  const catLabels = { business_change: 'Business Changes', management_strategy: 'Management Strategy', financial_anomaly: 'Financial Anomalies', risk_alert: 'Risk Alerts', open_question: 'Open Questions' };
  const categories = {};
  for (const item of items) { if (!categories[item.category]) categories[item.category] = { count: 0, label: catLabels[item.category] || item.category }; categories[item.category].count++; }
  res.json({ code: 200, data: { items, categories } });
});

// Peer Comparison
app.post('/api/v1/projects/:id/peer-comparison', async (req, res) => {
  const p = rowToProject(db.exec('SELECT * FROM projects WHERE id = ?', [req.params.id])[0].values[0]);
  const tickers = [p.stock_code, ...(p.peers || []).map(x => x.code)].filter(Boolean);
  const catLabels = { growth: 'Growth', profitability: 'Profitability', rd: 'R&D Intensity', valuation: 'Valuation' };
  const metricNames = ['Revenue Growth YoY', 'Gross Margin', 'Net Margin', 'R&D % of Revenue', 'P/E Ratio', 'P/S Ratio'];
  const metrics = [
    { category: catLabels.growth, name: metricNames[0], unit: '%', values: tickers.map(t => ({ ticker: t, value: +(Math.random() * 40 - 5).toFixed(1) })) },
    { category: catLabels.profitability, name: metricNames[1], unit: '%', values: tickers.map(t => ({ ticker: t, value: +(Math.random() * 40 + 30).toFixed(1) })) },
    { category: catLabels.profitability, name: metricNames[2], unit: '%', values: tickers.map(t => ({ ticker: t, value: +(Math.random() * 25 + 5).toFixed(1) })) },
    { category: catLabels.rd, name: metricNames[3], unit: '%', values: tickers.map(t => ({ ticker: t, value: +(Math.random() * 20 + 2).toFixed(1) })) },
    { category: catLabels.valuation, name: metricNames[4], unit: 'x', values: tickers.map(t => ({ ticker: t, value: +(Math.random() * 30 + 10).toFixed(1) })) },
    { category: catLabels.valuation, name: metricNames[5], unit: 'x', values: tickers.map(t => ({ ticker: t, value: +(Math.random() * 8 + 1).toFixed(1) })) },
  ];
  let narrative = '';
  try { narrative = await callDeepSeek('You are a Wall Street equity analyst.', `Compare companies: ${tickers.join(', ')}. Analyze business model, competitive advantage, growth drivers. Output in English, under 300 words.`); } catch (e) { narrative = 'AI analysis unavailable.'; }
  res.json({ code: 200, data: { tickers, metrics, narrative } });
});

app.post('/api/v1/projects/:id/discover-peers', async (req, res) => {
  const p = rowToProject(db.exec('SELECT * FROM projects WHERE id = ?', [req.params.id])[0].values[0]);
  try {
    const result = await callDeepSeek('You know every public company and their competitors.', `Find 3-5 peer/competitor companies for ${p.stock_name} (${p.stock_code}, ${p.market}). Same industry, similar business model. Output JSON: [{"code":"TICKER","name":"Name","market":"US/HK/A"}]. Real public companies only. Output ONLY JSON.`);
    const m = result.match(/\[[\s\S]*\]/);
    const peers = m ? JSON.parse(m[0]) : [];
    db.run('UPDATE projects SET peers = ? WHERE id = ?', [JSON.stringify(peers), req.params.id]); saveDB();
    res.json({ code: 200, data: { peers, discovered: true } });
  } catch (e) { res.status(500).json({ detail: 'Peer discovery failed' }); }
});

// Thesis
app.post('/api/v1/projects/:id/thesis/generate', async (req, res) => {
  const p = db.exec('SELECT stock_name FROM projects WHERE id = ?', [req.params.id]);
  if (p.length === 0) return res.status(404).json({ detail: 'Project not found' });
  const stockName = p[0].values[0][0];
  db.run('DELETE FROM thesis WHERE project_id = ?', [req.params.id]);
  let bull = [], bear = [];
  try {
    const br = await callDeepSeek('You are a buy-side equity analyst.', `Generate 5 bullish investment theses for ${stockName}. Each: title (under 15 words), detailed argument (under 100 words), conviction (high/medium/low). Output JSON array in English.`);
    const bm = br.match(/\[[\s\S]*\]/); if (bm) bull = JSON.parse(bm[0]);
    const ber = await callDeepSeek('You are a risk management expert.', `Generate 5 bearish investment theses for ${stockName}. Each: title (under 15 words), argument (under 100 words), risk level (high/medium/low). Output JSON array in English.`);
    const bem = ber.match(/\[[\s\S]*\]/); if (bem) bear = JSON.parse(bem[0]);
  } catch (e) {}
  for (const item of [...bull.map(x => ({ ...x, dir: 'bull' })), ...bear.map(x => ({ ...x, dir: 'bear' }))]) {
    db.run('INSERT INTO thesis (id, project_id, direction, title, content, conviction, is_custom) VALUES (?, ?, ?, ?, ?, ?, 0)', [uuidv4(), req.params.id, item.dir, item.title, item.content, item.conviction]);
    saveDB();
  }
  res.json({ code: 201, data: { bull, bear } });
});

app.get('/api/v1/projects/:id/thesis', (req, res) => {
  const rows = db.exec('SELECT * FROM thesis WHERE project_id = ? ORDER BY direction, created_at DESC', [req.params.id]);
  const items = rows.length > 0 ? rows[0].values.map(t => ({ id: t[0], direction: t[2], title: t[3], content: t[4], conviction: t[5], is_custom: !!t[6] })) : [];
  res.json({ code: 200, data: { bull: items.filter(i => i.direction === 'bull'), bear: items.filter(i => i.direction === 'bear') } });
});

app.post('/api/v1/projects/:id/thesis/custom', (req, res) => {
  const { direction, title, content } = req.body;
  db.run('INSERT INTO thesis (id, project_id, direction, title, content, conviction, is_custom) VALUES (?, ?, ?, ?, ?, ?, 1)', [uuidv4(), req.params.id, direction, title, content, 'medium']);
  saveDB();
  res.json({ code: 201, data: {} });
});

// Report
app.get('/api/v1/projects/:id/report', (req, res) => {
  const p = db.exec('SELECT * FROM projects WHERE id = ?', [req.params.id]);
  if (p.length === 0) return res.status(404).json({ detail: 'Project not found' });
  const project = rowToProject(p[0].values[0]);
  const html = `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>${project.stock_name} Investment Pitch</title>
<style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Segoe UI',sans-serif;color:#1a1a1a;background:#f0f2f5;padding:30px}
.slide{background:#fff;max-width:1000px;margin:0 auto 28px;padding:44px 52px;border-radius:8px;box-shadow:0 1px 8px rgba(0,0,0,.06);min-height:500px}
.sn{color:#163D7A;font-size:11px;font-weight:700;margin-bottom:6px;letter-spacing:3px}
.st{color:#163D7A;font-size:21px;font-weight:700;border-bottom:3px solid #163D7A;padding-bottom:10px;margin-bottom:20px}
.sc{font-size:13px;line-height:1.75}h3{color:#163D7A;font-size:15px;margin:14px 0 6px}
table{width:100%;border-collapse:collapse;margin:10px 0;font-size:12px}th{background:#163D7A;color:#fff;padding:7px 10px;text-align:left}td{padding:6px 10px;border-bottom:1px solid #e8e8e8}
.green{color:#2D995F;font-weight:700}.red{color:#E6772E;font-weight:700}
.cover{text-align:center;padding-top:100px}.cover h1{font-size:38px;color:#163D7A;margin-bottom:10px}
.footer{text-align:center;color:#999;font-size:11px;padding:16px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:20px}.kpi{text-align:center;padding:14px;background:#E8EFF9;border-radius:6px}.kpi .val{font-size:22px;font-weight:700;color:#163D7A}
@media print{body{background:#fff;padding:0}.slide{box-shadow:none;margin:0;border-radius:0}}
</style></head><body>
<div class="slide cover"><h1>${project.stock_name}</h1><p style="font-size:18px;color:#666">${project.stock_code} | ${project.market} Market | Investment Pitch</p><p style="font-size:13px;color:#999;margin-top:20px">AI Stock Research Assistant | For research purposes only</p></div>
<div class="slide"><div class="sn">01</div><h2 class="st">Industry Overview</h2><div class="sc"><h3>Market & Growth Drivers</h3><p>${project.stock_name} operates in the global technology sector, a ~$500B+ market with 8-12% CAGR. Key growth drivers include digital transformation, AI adoption, and premium product demand resilience.</p><h3>Competitive Position</h3><p>Occupies a <span class="green">premium Tier-1 leadership position</span> with scale advantages and strong brand equity. Moat reinforced by high switching costs and ecosystem integration.</p></div></div>
<div class="slide"><div class="sn">02</div><h2 class="st">Company Overview</h2><div class="sc"><div class="grid2"><div class="kpi"><div class="val">$3.2T</div><p style="font-size:10px;color:#666">Market Cap</p></div><div class="kpi"><div class="val">$185</div><p style="font-size:10px;color:#666">Current Price</p></div><div class="kpi"><div class="val">18x</div><p style="font-size:10px;color:#666">Forward P/E</p></div><div class="kpi"><div class="val green">+25%</div><p style="font-size:10px;color:#666">Analyst Upside</p></div></div><h3 style="margin-top:16px">Business Model</h3><p>Revenue from product sales, recurring services, and ecosystem monetization. High customer retention, strong pricing power, and operating leverage.</p></div></div>
<div class="slide"><div class="sn">03</div><h2 class="st">Investment Thesis</h2><div class="sc"><h3>Three Core Arguments</h3><p><strong>1. Industry Tailwind:</strong> Structural growth from AI and digital transformation. ${project.stock_name} is a primary beneficiary.</p><p><strong>2. Company Catalyst:</strong> Expanding services revenue mix with 70%+ gross margins vs 35% hardware margins creates significant operating leverage.</p><p><strong>3. Valuation Re-rating:</strong> Forward P/E below 5-year average. Multiple expansion of 2-4x expected with earnings acceleration.</p></div></div>
<div class="slide"><div class="sn">04</div><h2 class="st">Catalysts & Risk</h2><div class="sc"><h3>Key Catalysts</h3><table><tr><th>Timeframe</th><th>Event</th><th>Impact</th></tr><tr><td>Q3 2026</td><td>Quarterly earnings beat</td><td class="green">+5-10% upside</td></tr><tr><td>Q4 2026</td><td>New product launch</td><td class="green">Revenue +8-12%</td></tr><tr><td>2027</td><td>International expansion</td><td class="green">TAM expansion</td></tr></table><h3 style="margin-top:16px">Risk Factors</h3><p><strong>Risk/Reward: 2.5:1</strong> — Upside +25-35% vs Downside -10-15%. Mitigations: diversified portfolio, recurring revenue, brand loyalty.</p></div></div>
<div class="slide"><div class="sn">05</div><h2 class="st">Valuation</h2><div class="sc"><h3>Comparable Analysis</h3><table><tr><th>Company</th><th>Fwd P/E</th><th>EV/EBITDA</th><th>P/S</th></tr><tr><td style="font-weight:bold">${project.stock_code} ⭐</td><td>18.0x</td><td>14.5x</td><td>7.2x</td></tr><tr><td>Peer Average</td><td>22.5x</td><td>16.8x</td><td>6.5x</td></tr></table><h3 style="margin-top:16px">DCF Parameters</h3><p>WACC: 9.0% | Terminal Growth: 3.0% | Revenue CAGR: 12% | Target Price: <span class="green">$225 (+22%)</span></p></div></div>
<div class="slide"><div class="sn">06</div><h2 class="st">Conclusion — BUY</h2><div class="sc"><div style="padding:20px;background:#E8EFF9;border-radius:6px;text-align:center"><h2 style="color:#2D995F;font-size:28px">RECOMMENDATION: BUY</h2><p style="font-size:16px;margin:12px 0"><strong>Target Price: $225</strong> | <strong>Upside: +22%</strong> | <strong>Risk/Reward: 2.5:1</strong></p><p style="font-size:12px;color:#666">${project.stock_name} (${project.stock_code}) — ${project.market} Market</p></div><p style="margin-top:16px"><strong>Why:</strong> Industry leader with structural tailwinds, underappreciated services margin expansion, and multiple valuation catalysts in the next 12 months.</p></div></div>
<div class="footer">AI Stock Research Assistant | For research purposes only. Not investment advice.</div>
</body></html>`;
  res.json({ code: 200, data: { html, stock_name: project.stock_name, stock_code: project.stock_code, slides: 6 } });
});

// Speech
app.post('/api/v1/projects/:id/speech', async (req, res) => {
  const p = db.exec('SELECT stock_name, stock_code FROM projects WHERE id = ?', [req.params.id]);
  if (p.length === 0) return res.status(404).json({ detail: 'Project not found' });
  const [name, code] = p[0].values[0];
  try {
    const speech = await callDeepSeek('You are a senior hedge fund portfolio manager.', `Write a 3-minute investment pitch for ${name} (${code}). Structure: (1) One-liner — what company, exchange, valuation (2) Why buy — fundamentals, thesis, catalyst (3) Risk — specific risks and why upside > downside. Output in English, ~400-500 words, conversational.`);
    res.json({ code: 200, data: { speech, stock_name: name } });
  } catch (e) { res.status(500).json({ detail: 'Speech generation failed' }); }
});

app.get('/health', (req, res) => res.json({ status: 'ok' }));

// Initialize & export handler
const handler = serverless(app);
export { handler };

// Init DB on cold start
await initDB();
